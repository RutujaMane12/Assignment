let size=5;
const myinputarr=[];
for(var a=0; a<size; a++) 
{
     
     
    myinputarr[a] = prompt('Enter array Element ' + (a+1));
}

console.log(myinputarr);
myinputarr.sort();
arr1=myinputarr.reverse();
console.log(arr1);



// console.log(newArray);
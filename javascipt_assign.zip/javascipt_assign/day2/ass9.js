function max(arg1,arg2,arg3)
{
     return Math.max(arg1,arg2,arg3);
}

console.log(`max of array:${max(11,23,21)}`);

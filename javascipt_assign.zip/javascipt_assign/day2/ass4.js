function login(username='CT',password='CT')
{
    console.log('the  user name is: '+username);
    console.log('the  password is: '+password); 
}
login('Rutuja','1234');